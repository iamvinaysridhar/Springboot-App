package com.springboottest;

import org.junit.Test;
import org.springframework.core.annotation.Order;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.springboot.account.details.Account;
import com.springboot.customer.details.Customer;


import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashSet;
import java.util.Set;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import com.fasterxml.jackson.databind.ObjectMapper;



@SpringBootTest
@AutoConfigureMockMvc
@RunWith(SpringRunner.class)
public class CapstoneProjectControllerTest {

	@Autowired
	MockMvc m;
	
	
	
	@Test
	@Order(1)
	public void sendMoney() throws Exception{
		this.m.perform((RequestBuilder) ((ResultActions) post("/vinay/moneytransfer/1/2/1000.00")
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk()));
	}
	
	@Test
	@Order(2)
	public void getCustByAadhaar() throws Exception{
		this.m.perform(get("/vinay/retrieve/aadhaar/12345678"))
		.andDo(print())
		.andExpect(status().isOk())
		.andExpect(MockMvcResultMatchers.jsonPath("$.aadhaarNo").value(12345678));
	}
	
	@Test
	@Order(3)
	public void getCustByMobile() throws Exception{
		this.m.perform(get("/vinay/retrieve/mobile/1223143233"))
		.andDo(print())
		.andExpect(status().isOk())
		.andExpect(MockMvcResultMatchers.jsonPath("$.customerPhone").value(1223143233));
	}
	
	@Test
	@Order(4)
	public void getAllCusto() throws Exception{
		this.m.perform(get("/vinay/retrieve"))
		.andDo(print())
		.andExpect(status().isOk())
		.andExpect(MockMvcResultMatchers.jsonPath("$[0].aadhaarNo").value(12345678));
	}
	
	@Test
	@Order(5)
	public void updEmail() throws Exception{
		((ResultActions) ((MockHttpServletRequestBuilder) this.m.perform(put("/vinay/12345678/vinay@india.com")))
		.contentType(MediaType.APPLICATION_JSON)
		.accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(MockMvcResultMatchers.jsonPath("$.aadhaarNo").value(12345678))
		.andExpect(MockMvcResultMatchers.jsonPath("$.customerEmail").value("vinay@india.com"));
	}
	
	@Test
	@Order(6)
	public void updMobile() throws Exception{
		((ResultActions) ((MockHttpServletRequestBuilder) this.m.perform(put("/vinay/12345678/911111111")))
		.contentType(MediaType.APPLICATION_JSON)
		.accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(MockMvcResultMatchers.jsonPath("$.aadhaarNo").value(12345678))
		.andExpect(MockMvcResultMatchers.jsonPath("$.customerPhone").value(911111111));
	}
	
	private static String asJsonString(final Object obj) {
		try {
			return new ObjectMapper().writeValueAsString(obj);
		}
		catch(Exception e) {
			throw new RuntimeException(e);
		}
	}
	@Test
	@Order(7)
	public void creAcc() throws Exception{
		Set<Customer> sc=new HashSet<>();
		sc.add(new Customer(7867654,"Sridhar",438723897,"sridhar@vinay.com","Male",45));
		Account a=new Account(1234,"Savings",20000,false,sc);
		this.m.perform((RequestBuilder) ((ResultActions) post("/vinay/accountcreation")
		.content(asJsonString(a))
		.contentType(MediaType.APPLICATION_JSON)
		.accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(MockMvcResultMatchers.jsonPath("$.accountNo").value(1234)));
		
		
	}

	
	

}
