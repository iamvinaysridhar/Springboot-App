package com.springboot.repository;



import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.springboot.customer.details.Customer;

@Transactional
@Repository
public interface CustRep extends JpaRepository<Customer,Long>{
	
	

	@Modifying
	@Query("update Customer c set c.customerEmail=: customerEmail where c.customerAadhaarNo=: customerAadhaarNo")
	int updtEmail(@Param("customerAadhaarNo") long customerAadhaarNo, @Param("customerEmail") String customerEmail);

	@Modifying
	@Query("update Customer c set c.customerPhone=: customerPhone where c.customerAadhaarNo=: customerAadhaarNo")
	int updtMobile(@Param("customerAadhaarNo") long customerAadhaarNo, @Param("customerPhone") long customerPhone);
}
