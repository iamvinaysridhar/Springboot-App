package com.springboot.exceptions;

public class AccountCreateException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccountCreateException(String log) {
		super (log);
	}

}
