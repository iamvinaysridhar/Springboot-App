create table account(
accountNo integer, accountType varchar2(10), balance double, isCurrentOrSavings boolean, primary key(accountNo)
);

create table customer(
customerAadhaarNo integer, customerName varchar2(20), customerPhone integer, customerEmail varchar2(20), customerSex varchar2(7), customerAge integer, primary key(customerAadhaarNo)
);

create table sync_table(
accountNo integer, customerAadhaarNo integer, primary key(accountNo,customerAadhaarNo), foreign key(customerAadhaarNo) references customer(customerAadhaarNo), foreign key(accountNo) references account(accountNo)
);

insert into account values(1,'Savings',35000,false);
insert into customer values(12345678,'Vinay.S','1223143233','vinay@vinay.com','Male',22);
insert into sync_table values(1,12345678);