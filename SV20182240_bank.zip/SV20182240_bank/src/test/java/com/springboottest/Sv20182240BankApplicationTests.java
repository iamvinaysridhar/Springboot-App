package com.springboottest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sv20182240BankApplicationTests {

	@Test
	void contextLoads() {
	}

}
