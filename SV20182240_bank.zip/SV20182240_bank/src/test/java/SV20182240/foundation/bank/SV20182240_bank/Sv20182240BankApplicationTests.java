package SV20182240.foundation.bank.SV20182240_bank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sv20182240BankApplicationTests {

	@Test
	void contextLoads() {
	}

}
