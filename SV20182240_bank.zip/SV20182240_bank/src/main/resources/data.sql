create table account(
accountNo integer, accountType varchar2(10), balance double, isCurrentOrSavings boolean, primary key(accountNo)
);

create table customer(
customerName varchar2(20), customerPhone integer, customerEmail varchar2(20), customerSex varchar2(7), customerAge integer, aadhaarNo integer(20), primary key(aadhaarNo)
);

create table sync_table(
accno integer, aadhaar integer(20), primary key(accno,aadhaar), foreign key(aadhaar) references customer, foreign key(accno) references account
);

insert into account values(1,'Savings',35000,false);
insert into customer values('Vinay.S','1223143233','vinay@vinay.com','Male',22,12345678);
insert into sync_table values(1,12345678);