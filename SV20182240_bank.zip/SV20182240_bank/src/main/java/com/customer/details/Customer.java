package com.customer.details;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


import com.account.details.Account;

@Entity
@Table(name="customer")
public class Customer implements Serializable {
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Column
	String customerName;
	@Column
	long customerPhone;
	@Column
	String customerEmail;
	@Column
	String customerSex;
	@Column
	int customerAge;
	@Id
	long aadhaarNo;
	
	@ManyToMany(fetch=FetchType.EAGER, cascade=CascadeType.ALL, mappedBy="c")
	Set<Account> ac=new HashSet<>();
	
	
	public Customer(String customerName, long customerPhone, String customerEmail,
			String customerSex, int customerAge, long aadhaarNo) {
		super();
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.customerEmail = customerEmail;
		this.customerSex = customerSex;
		this.customerAge = customerAge;
		this.aadhaarNo = aadhaarNo;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", customerPhone=" + customerPhone + ", customerEmail="
				+ customerEmail + ",customerSex=" + customerSex
				+ ", customerAge=" + customerAge + ", aadhaarNo=" + aadhaarNo + "]";
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public long getCustomerPhone() {
		return customerPhone;
	}
	public void setCustomerPhone(long customerPhone) {
		this.customerPhone = customerPhone;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerSex() {
		return customerSex;
	}
	public void setCustomerSex(String customerSex) {
		this.customerSex = customerSex;
	}
	public int getCustomerAge() {
		return customerAge;
	}
	public void setCustomerAge(int customerAge) {
		this.customerAge = customerAge;
	}
	public long getAadhaarNo() {
		return aadhaarNo;
	}
	public void setAadhaarNo(long aadhaarNo) {
		this.aadhaarNo = aadhaarNo;
	}
	
	
}