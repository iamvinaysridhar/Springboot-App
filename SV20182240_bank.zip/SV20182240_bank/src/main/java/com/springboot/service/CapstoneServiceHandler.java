package com.springboot.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.account.details.Account;
import com.springboot.customer.details.Customer;
import com.springboot.exceptions.AadhaarNotFoundException;
import com.springboot.exceptions.AccountCreateException;
import com.springboot.exceptions.MobileNotFoundException;
import com.springboot.exceptions.NoBalanceException;
import com.springboot.repository.AccountRep;
import com.springboot.repository.CustRep;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CapstoneServiceHandler {
	Logger logger=(Logger) LoggerFactory.getLogger(CapstoneServiceHandler.class);	
	
	@Autowired
	CustRep cr;
	
	@Autowired
	AccountRep ar;
	

	public Account crtAccount(Account acc) throws Exception {
		// TODO Auto-generated method stub
		logger.info("Account acc:"+acc.toString());
		Account returnVal=null;
		boolean isCorS = acc.getIsCurrentOrSavings();
		if(isCorS) {
			Set<Customer> c = acc.getAc();
			if(c.size()>1) {
				logger.error("Cannot create current account -- customer already has a savings account");
				throw new AccountCreateException ("Cannot create current account -- customer already has a savings account");
			}
			
		}
		else if(!(isCorS)) {
			Set<Customer> c = acc.getAc();
			if(c.size()>1) {
				logger.error("Cannot create savings account -- customer already has a current account");
				throw new AccountCreateException ("Cannot create savings account -- customer already has a current account");
			}
			
		}
		else {
			returnVal=ar.save(acc);
			logger.info("Bank account creation is done");
		}
		
		return returnVal;
	}

	public Customer updtEmail(long aadhaarNo, String email) {
		// TODO Auto-generated method stub
		logger.info("Update your email");
		Customer c=null;
		Optional<Customer> oc=cr.findById(aadhaarNo);
		if(oc.isPresent()) {
			cr.updtEmail(aadhaarNo, email);
			c=oc.get();
			c.setCustomerEmail(email);
			logger.info("Successfully updated email");
			return c;
		}
		else {
			logger.error("Invalid aadhaar no");
			throw new AadhaarNotFoundException(aadhaarNo);
		}
	}

	public Customer updtMobile(long aadhaarNo, long mobile) {
		// TODO Auto-generated method stub
		logger.info("Update your mobile");
		Customer c=null;
		Optional<Customer> oc=cr.findById(mobile);
		if(oc.isPresent()) {
			cr.updtMobile(aadhaarNo,mobile);
			c=oc.get();
			c.setCustomerPhone(mobile);
			logger.info("Successfully updated mobile");
			return c;
		}
		else {
			logger.error("Invalid aadhaar no");
			throw new AadhaarNotFoundException(aadhaarNo);
		}
	}

	public Object transferAmt(int sender, int receiver, double money) {
		// TODO Auto-generated method stub
		logger.info("Money transfer");
		Account p = ar.getById(sender);
		Account r=ar.getById(receiver);
		int returnVal=0;
		
		double ap= p.getBalance();
		double acr=p.getBalance();
		if(ap>= money) {
			logger.info("Transaction started");
			p.setBalance(ap-money);
			r.setBalance(acr+money);
			ar.saveAll(Arrays.asList(r,p));
			logger.info("Money successfully transfered");
			returnVal=1;
			return returnVal;
		}
		else {
			logger.error("Insufficent balance amount");
			throw new NoBalanceException("Insufficient balance amount");
		}
	}

	public Customer getCustomerbyAadhaarNo(long aadhaarNo) {
		// TODO Auto-generated method stub
		logger.info("Aadhar no:"+ aadhaarNo);
		Customer c=null;
		Optional<Customer> oc=cr.findById(aadhaarNo);
		if(oc.isPresent()) {
			logger.info("Here are the customer details");
			c=oc.get();
			return c;
		}
		else {
			logger.error("No such customer found");
			throw new AadhaarNotFoundException(aadhaarNo);
		}
	}

	public Customer getCustomerbyMobile(long mobile) {
		// TODO Auto-generated method stub
		logger.info("Mobile no:"+ mobile);
		Customer c=null;
		Optional<Customer> oc=cr.findById(mobile);
		if(oc.isPresent()) {
			logger.info("Here are the customer details");
			c=oc.get();
			return c;
		}
		else {
			logger.error("No such customer found");
			throw new MobileNotFoundException(mobile);
		}
	}

	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		logger.info("All customer details");
		List<Customer> c = cr.findAll();
		logger.info(c.toString());
		if(c.isEmpty()) {
			logger.error("No customers available");
		}
		return c;
	}

}
