package com.springboot.exceptions;

public class AadhaarNotFoundException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AadhaarNotFoundException(long aadhaarNo) {
		super();
	}

}
