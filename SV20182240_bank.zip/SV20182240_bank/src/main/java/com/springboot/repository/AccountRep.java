package com.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.account.details.Account;

@Repository
public interface AccountRep extends JpaRepository<Account,Integer>{

}
