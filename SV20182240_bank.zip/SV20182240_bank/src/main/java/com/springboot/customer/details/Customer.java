package com.springboot.customer.details;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.springboot.account.details.Account;

@Component
@Entity
@Table(name="customer")
public class Customer implements Serializable {
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	long customerAadhaarNo;
	@Column
	String customerName;
	@Column
	long customerPhone;
	@Column
	String customerEmail;
	@Column
	String customerSex;
	@Column
	int customerAge;
	
	@Autowired
	Account ac;
	
	
	@JsonIgnore
	@ManyToMany(fetch=FetchType.EAGER, cascade=CascadeType.ALL, mappedBy="ac")
	Set<Account> ac1=new HashSet<>();
	
	
	public Customer(long customerAadhaarNo,String customerName, long customerPhone, String customerEmail,
			String customerSex, int customerAge) {
		super();
		this.customerAadhaarNo = customerAadhaarNo;
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.customerEmail = customerEmail;
		this.customerSex = customerSex;
		this.customerAge = customerAge;
		
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Customer [customerAadhaarNo=" + customerAadhaarNo + ", customerName=" + customerName + ", customerPhone="
				+ customerPhone + ", customerEmail=" + customerEmail + ", customerSex=" + customerSex + ", customerAge="
				+ customerAge + ", ac1=" + ac1 + "]";
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public long getCustomerPhone() {
		return customerPhone;
	}
	public void setCustomerPhone(long customerPhone) {
		this.customerPhone = customerPhone;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerSex() {
		return customerSex;
	}
	public void setCustomerSex(String customerSex) {
		this.customerSex = customerSex;
	}
	public int getCustomerAge() {
		return customerAge;
	}
	public void setCustomerAge(int customerAge) {
		this.customerAge = customerAge;
	}
	public long getCustomerAadhaarNo() {
		return customerAadhaarNo;
	}
	public void setCustomerAadhaarNo(long customerAadhaarNo) {
		this.customerAadhaarNo = customerAadhaarNo;
	}
	
	
}