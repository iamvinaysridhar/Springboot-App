package com.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.account.details.Account;
import com.springboot.customer.details.Customer;
import com.springboot.service.CapstoneServiceHandler;

@RestController
@RequestMapping("/vinay")
public class CapstoneProjectController {

	@Autowired
	CapstoneServiceHandler csh;
	
	@PostMapping("/accountcreation")
	public ResponseEntity<Account> createAcc(@RequestBody Account acc) throws Exception{
		Account a = csh.crtAccount(acc);
		return new ResponseEntity<Account>(a,HttpStatus.OK);
	}
	
	@PutMapping("/customer/{aadhaar}/{email}")
	public Customer editEmail(@PathVariable("aadhaar") long aadhaarNo, @PathVariable("email") String email) {
		return csh.updtEmail(aadhaarNo,email);
	}
	@PutMapping("/customer/{aadhaar}/{mobile}")
	public Customer editMobile(@PathVariable("aadhaar") long aadhaarNo, @PathVariable("mobile") long mobile) {
		return csh.updtMobile(aadhaarNo,mobile);
	}
	@PostMapping("/moneytransfer/{sender}/{receiver}/{money}")
	public ResponseEntity<?> sendMoney(@PathVariable int sender, @PathVariable int receiver, @PathVariable double money){
		return new ResponseEntity<>(csh.transferAmt(sender,receiver,money),HttpStatus.OK);
	}
	
	@GetMapping("/retrieve/aadhaar/{aadhaar}")
		public ResponseEntity<Customer> retrieveCustomerbyAadhaar(@PathVariable long aadhaarNo){
			return new ResponseEntity<Customer>(csh.getCustomerbyAadhaarNo(aadhaarNo),HttpStatus.OK);
	}
	@GetMapping("/retrieve/mobile/{mobile}")
	public ResponseEntity<Customer> retrieveCustomerbyMobile(@PathVariable long mobile){
		return new ResponseEntity<Customer>(csh.getCustomerbyMobile(mobile),HttpStatus.OK);
}
	@GetMapping("/retrieve")
	public List<Customer> getAllCust(){
		return csh.getAllCustomers();
	}
}
