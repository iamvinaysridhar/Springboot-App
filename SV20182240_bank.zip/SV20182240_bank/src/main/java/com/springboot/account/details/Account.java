package com.springboot.account.details;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.springboot.customer.details.Customer;

@Entity
@Table(name="account")
@Component
public class Account implements Serializable {

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountType=" + accountType + ", balance=" + balance
				+ ", isCurrentOrSavings=" + isCurrentOrSavings + ", ac=" + ac + "]";
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Id
	int accountNo;
	@Column
	String accountType;
	@Column
	double balance;
	@Column
	Boolean isCurrentOrSavings;
	
	@ManyToMany(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@JoinTable(
			name="sync_table",
			joinColumns= @JoinColumn(name="accountNo"),
			inverseJoinColumns=@JoinColumn(name="customerAadhaarNo"))
	Set<Customer> ac = new HashSet<>();
	
	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Boolean getIsCurrentOrSavings() {
		return isCurrentOrSavings;
	}

	public void setIsCurrentOrSavings(Boolean isCurrentOrSavings) {
		this.isCurrentOrSavings = isCurrentOrSavings;
	}

	public Set<Customer> getAc() {
		return ac;
	}

	public void setC(Set<Customer> ac) {
		this.ac = ac;
	}

	
	
	

	public Account(int accountNo, String accountType, double balance, Boolean isCurrentOrSavings, Set<Customer> ac) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.balance = balance;
		this.isCurrentOrSavings = isCurrentOrSavings;
		this.ac = ac;
	}

	public Account(String accountType, double balance, Boolean isCurrentOrSavings, Set<Customer> ac) {
		super();
		this.accountType = accountType;
		this.balance = balance;
		this.isCurrentOrSavings = isCurrentOrSavings;
		this.ac = ac;
	}
	

}
