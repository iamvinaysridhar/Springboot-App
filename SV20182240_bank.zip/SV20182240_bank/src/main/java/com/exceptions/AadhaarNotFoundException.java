package com.exceptions;

public class AadhaarNotFoundException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AadhaarNotFoundException(long aadhaar) {
		super();
	}

}
