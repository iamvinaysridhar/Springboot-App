package com.exceptions;

public class MobileNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MobileNotFoundException(long mobile) {
		super();
	}

}
