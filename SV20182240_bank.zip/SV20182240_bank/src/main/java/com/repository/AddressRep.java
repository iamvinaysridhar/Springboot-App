package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.customer.details.Address;

public interface AddressRep extends JpaRepository<Address,Integer> {

}
