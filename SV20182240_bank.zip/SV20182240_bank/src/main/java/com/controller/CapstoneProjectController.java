package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.account.details.Account;
import com.customer.details.Customer;
import com.service.CapstoneServiceHandler;

@RestController
public class CapstoneProjectController {

	@Autowired
	CapstoneServiceHandler csh;
	
	@PostMapping("/accountcreation")
	public ResponseEntity<Account> createAcc(@RequestBody Account acc) throws Exception{
		Account a = csh.crtAccount(acc);
		return new ResponseEntity<Account>(a,HttpStatus.CREATED);
	}
	
	@PutMapping("/customer/{aadhaar}/{email}")
	public Customer editEmail(@PathVariable("aadhaar") long aadhaar, @PathVariable("email") String email) {
		return csh.updtEmail(aadhaar,email);
	}
	@PutMapping("/customer/{aadhaar}/{mobile}")
	public Customer editMobile(@PathVariable("aadhaar") long aadhaar, @PathVariable("mobile") long mobile) {
		return csh.updtMobile(aadhaar,mobile);
	}
	@PostMapping("/moneytransfer/{sender}/{receiver}/{money}")
	public ResponseEntity<?> sendMoney(@PathVariable int sender, @PathVariable int receiver, @PathVariable double money){
		return new ResponseEntity<>(csh.transferAmt(sender,receiver,money),HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/retrieve/{aadhaar}")
		public ResponseEntity<Customer> retrieveCustomerbyAadhaar(@PathVariable long aadhaar){
			return new ResponseEntity<Customer>(csh.getCustomerbyAadhaarNo(aadhaar),HttpStatus.FOUND);
	}
	@GetMapping("/retrieve/{mobile}")
	public ResponseEntity<Customer> retrieveCustomerbyMobile(@PathVariable long mobile){
		return new ResponseEntity<Customer>(csh.getCustomerbyMobile(mobile),HttpStatus.FOUND);
}
	@GetMapping("/retrieve")
	public List<Customer> getAllCust(){
		return csh.getAllCustomers();
	}
}
