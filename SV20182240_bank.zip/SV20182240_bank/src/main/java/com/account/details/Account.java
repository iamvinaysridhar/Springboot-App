package com.account.details;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.customer.details.Customer;

@Entity
@Table(name="account")
public class Account implements Serializable {

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountType=" + accountType + ", balance=" + balance
				+ ", isCurrentOrSavings=" + isCurrentOrSavings + ", c=" + c + "]";
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	int accountNo;
	@Column
	String accountType;
	@Column
	double balance;
	@Column
	Boolean isCurrentOrSavings;
	
	@ManyToMany(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@JoinTable(
			name="sync_table",
			joinColumns= @JoinColumn(name="accno"),
			inverseJoinColumns=@JoinColumn(name="aadhar"))
	
	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Boolean getIsCurrentOrSavings() {
		return isCurrentOrSavings;
	}

	public void setIsCurrentOrSavings(Boolean isCurrentOrSavings) {
		this.isCurrentOrSavings = isCurrentOrSavings;
	}

	public Set<Customer> getC() {
		return c;
	}

	public void setC(Set<Customer> c) {
		this.c = c;
	}

	
	
	Set<Customer> c = new HashSet<>();

	public Account(int accountNo, String accountType, double balance, Boolean isCurrentOrSavings, Set<Customer> c) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.balance = balance;
		this.isCurrentOrSavings = isCurrentOrSavings;
		this.c = c;
	}

	public Account(String accountType, double balance, Boolean isCurrentOrSavings, Set<Customer> c) {
		super();
		this.accountType = accountType;
		this.balance = balance;
		this.isCurrentOrSavings = isCurrentOrSavings;
		this.c = c;
	}
	

}
